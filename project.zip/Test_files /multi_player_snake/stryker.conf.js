module.exports = {
    testRunner: "mocha",
    mutator: "javascript",
    mutate: [
        // 'app/services/admin-service.js',
        // 'app/services/board-occupancy-service.js',
        // 'app/services/bot-direction-service.js',
        // 'app/services/color-service.js',
        'app/services/coordinate-service.js',
        // 'app/services/image-service.js',
        // 'app/services/name-service.js',
        // 'app/services/notification-service.js',
        // 'app/services/player-spawn-service.js',

      ],
    mochaOptions: {
        spec: ['test/CoordinateServiceTest.js'], 
    },
   
    thresholds: { 
      high: 80, 
      low: 60, 
      break: 50
    },
    reporters: ["html", "clear-text", "progress"],
    coverageAnalysis: "perTest",
    concurrency: 4
  };
  

  